import requests
import os
import subprocess as sub
import asyncio
import time

async def run(cmd):
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE)
    stdout, stderr = await proc.communicate()

    print(f'[{cmd!r} exited with {proc.returncode}]')
    if stdout:
        print(f'[stdout]\n{stdout.decode()}')
    if stderr:
        print(f'[stderr]\n{stderr.decode()}')

def session_for_src_addr(addr: str) -> requests.Session:
    """
    Create `Session` which will bind to the specified local address
    rather than auto-selecting it.
    """
    session = requests.Session()
    for prefix in ('http://', 'https://'):
        session.get_adapter(prefix).init_poolmanager(
            # those are default values from HTTPAdapter's constructor
            connections=requests.adapters.DEFAULT_POOLSIZE,
            maxsize=requests.adapters.DEFAULT_POOLSIZE,
            # This should be a tuple of (address, port). Port 0 means auto-selection.
            source_address=(addr, 0),
        )

    return session

async def tcpdump(interface: str):
	await run("tcpdump -G 4 -W 1 -i "+ interface + " -w test.pcap")

async def main():
	tcpdump_task = asyncio.create_task(tcpdump('host 10.128.128.25'))
	s = session_for_src_addr('10.128.128.25')

	print(s.get('https://daringfireball.net').text)

	await tcpdump_task
	print("finished")

asyncio.run(main())



##reference
##s.proxies={'https': 'socks5://localhost:9050', 'http': 'socks5://localhost:9050'}
##sub.run("ifconfig gif1 destroy", shell = True)
##inet 123.123.22.22 netmask 0xff000000 broadcast 123.255.255.255
## create vlan : sudo ifconfig gif1 vlan 21 vlandev en0
##sudo ifconfig gif1 vlandev en0
# sub.run("sudo ifconfig gif1 create", shell = True)
# sub.run("sudo ifconfig gif1 vlan 21 vlandev en0", shell = True)
# sub.run("sudo ifconfig gif1 alias 123.123.22.23", shell = True)
# sub.run("sudo ifconfig", shell = True)